## Courseplay v4.01

* Tractor icon by Olivier Guin - under "CC BY 3.0" license
* Globe icon by Nicholas Menghini - under "CC BY 3.0" license
* Speed gauge icon by Márcio Duarte - under "CC BY 3.0" license
* Gear icon by Johan H. W. Basberg - Public Domain (CC0 1.0)
* Arrow icon by Thomas Le Bas - under "CC BY 3.0" license
* Folder icons by Sergio Calcara - under "CC BY 3.0" license
* Trash can icon by Ruben Steeman - under "CC BY 3.0" license
* Floppy disk icon by Cor Tiemens - under "CC BY 3.0" license
* Copy icon part of "Font Awesome" by Dave Gandy - under "CC BY 3.0" license
* Refresh icon by Edward Boatman - under "CC BY 3.0" license
* Calculator icon by Scott Lewis - under "CC BY 3.0" license


* "Diamond", start, stop, wait and cross sign i3Ds by Claus Pedersen (Satis)

* All other icons and graphics by Jakob Tischler

___

## Translations

* Chinese: Simba76
* Czech: Albi
* Dutch: Pewemo
* French: Gui7545
* Hungarian: Chris von Bone
* Italian: JD7530, Cristiano Magro
* Polish: Ziuta
* Portuguese (BR): Admilson
* Portuguese (PT): PTAzores
* Russian: Bernelli
* Spanish: JFMtb, PromGames

___

## Former Developers
* Jakob Tischler
* Bastian82
* Lautschreier
* Horoman
* Hummel
* Skydancer
* Wolverin0815
