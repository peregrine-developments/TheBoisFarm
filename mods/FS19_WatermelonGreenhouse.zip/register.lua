print();

local modDirectory = g_currentModDirectory

function onLoadMapFinished(mission, node)
	local pricewatermelon = g_fillTypeManager:getFillTypeByName("MAIZE").pricePerLiter
	
	
	if node ~= 0 then
	
	local watermelonHudFile = "textures/hud_fill_watermelon.dds"
	local watermelonHudFileSmall = "textures/hud_fill_watermelon_small.dds"
	
    local watermelonFilType = g_fillTypeManager:addFillType("WATERMELON", g_i18n:getText("watermelon"), true, pricewatermelon * 1.0, 0.00045, math.rad(40), watermelonHudFile, watermelonHudFileSmall,modDirectory, nil, { 1, 1, 1 }, nil, false)
	 
	g_currentMission.hud.fillLevelsDisplay:refreshFillTypes(g_fillTypeManager)
	end;
end;

function load(id, xmlFile, key,customEnvironment)
	local hasmaize =false
	local haswatermelon=false	
	
	
	local object=id
	if object == nil then
	else
	hasmaize =false
	haswatermelon=false
	
	
	for i,filltype in pairs(object.acceptedFillTypes) do
	local fillname=g_fillTypeManager.indexToName[i]
		if fillname == "MAIZE" then
		hasmaize=true
	end;
		if fillname == "WATERMELON" then
		haswatermelon=true
	end;
	   
end;

		if hasmaize and not haswatermelon then
		local filltypen = g_fillTypeManager:getFillTypeIndexByName("WATERMELON")
		local price = g_fillTypeManager:getFillTypeByName("WATERMELON").pricePerLiter
			object:addAcceptedFillType(filltypen,price,true,false)
			object.priceMultipliers[ g_fillTypeManager:getFillTypeIndexByName("WATERMELON")]=object.priceMultipliers[ g_fillTypeManager:getFillTypeIndexByName("MAIZE")]
			object:initPricingDynamics()
		end;
		
	end;
end;

FSBaseMission.loadMapFinished = Utils.prependedFunction(FSBaseMission.loadMapFinished, onLoadMapFinished)
SellingStation.load = Utils.appendedFunction(SellingStation.load, load)