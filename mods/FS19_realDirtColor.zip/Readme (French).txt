- = [Couleur de salet� r�elle pour FS19] = -

Auteur: ViperGTS96
-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -

10 param�tres de couleur pour interpoler entre.

-Salet� brune
-Boue brune
-Slurry / Digestat
-Fumier
-Salet� rouge/Boue rouge
-Citron vert
-Neige
-Herbe
-Balle

-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -

*Remarques
----------

-Pour que la couleur de l'herbe prenne effet, le v�hicule doit �tre entour� d'herbe mouill�e ou sur un "champ" d'herbe. (en raison de l'humidit� sur le terrain, etc.)


-Ne saisissez "type de remplissage"; Il n'y a pas encore de neige dans le jeu, mais il est pr�t pour cela.


-Les cartes du sud utilisent "la salet� rouge et la boue" au lieu de brunir lors de la d�tection du nom de la carte. Ces noms peuvent �tre ajout�s au fichier settings.xml.


Le changement de couleur est r�glable via le fichier settings.xml ("<colorSettings speed =" 0.005 "/>") (Baissez la valeur (l�g�rement) � la vitesse la plus lente)

-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -


- Ajouter ce qui suit � un v�hicule xml pour outrepasser la limite maxNumOfWheels ..

  
  <realDirtColor ignoreRDCWheelLimit = "true" />


-------------------------------------------------- -


- Ajouter ce qui suit � un xml de v�hicule pour forcer le mode simple au v�hicule / outil.

  
    <realDirtColor useSimpleMode = "true" />

  
-------------------------------------------------- -

- Ajoutez ce qui suit � un xml de v�hicule pour d�sactiver la couleur de la salet� r�elle pour le v�hicule / l'outil.
  
    <realDirtColor disable = "true" />
    

-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -

* Modding avec la vraie couleur de salet� *
----------------------------

Si des pi�ces du v�hicule sont supprim�es / ajout�es pendant le jeu (et non dans un magasin ou un atelier de r�paration), elles doivent �tre supprim�es / ajout�es aux r�f�rences "Couleur de salet� r�elle" du v�hicule.

Pour supprimer une pi�ce, appelez >> realDirtColor: removePart (self, partToRemove);      * (Cette fonction retournera "true" si la pi�ce a �t� supprim�e avec succ�s, sinon false)

Pour ajouter une pi�ce, appelez >> realDirtColor: addPart (table, partToadd);

-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -

www.vipergts96.com/fsim/