- = [Real Dirt Color for FS19] = -

Autor: ViperGTS96
-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -

10 ajustes de color para interpolar entre.

-Tierra sucia
-Barro Marr�n
-Suave / Digestato
-Esti�rcol
-Red Dirt
-Barro rojo
-Lima
-Nieve
-Hierba
-Paja

-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -

* Notas
----------

-Para que el color del c�sped se vea afectado, el veh�culo debe estar alrededor de c�sped suelto (plantas de relleno) o estar en un "campo" de c�sped. (debido a la humedad del campo, etc.)


-Snow "filltype"; Todav�a no hay nieve en el juego, pero est� listo para ello.


-Los mapas del sur utilizan "Red dirt & Mud" en lugar de marr�n al detectar el nombre del mapa. Estos nombres se pueden agregar al archivo settings.xml.


-La velocidad de cambio de color se puede ajustar a trav�s del archivo settings.xml ("<colorSettings speed =" 0.005 "/>") (Baje el valor (ligeramente) para disminuir la velocidad)

-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -


- Agregue lo siguiente a un xml de veh�culo para anular el l�mite de MaxNumOfWheels.

  
  <realDirtColor ignoreRDCWheelLimit = "true" />


-------------------------------------------------- -


- Agregue lo siguiente a un veh�culo xml para forzar el modo simple en el veh�culo / herramienta.

  
    <realDirtColor useSimpleMode = "true" />

  
-------------------------------------------------- -

- Agregue lo siguiente a un xml de veh�culo para deshabilitar el Color de la suciedad real para el veh�culo / herramienta.
  
    <realDirtColor disable = "true" />
    

-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -

* Modding con Real Dirt Color *
----------------------------

Si las partes del veh�culo se eliminan / agregan durante el juego (no en una tienda o taller de reparaci�n), entonces las partes deben ser eliminadas / agregadas a las referencias del "Real Dirt Color" del veh�culo.

Para eliminar una llamada de parte >> realDirtColor: removePart (self, partToRemove);      * (Esta funci�n devolver� "true" si la pieza se elimin� con �xito, de lo contrario es false)

Para agregar una llamada de parte >> realDirtColor: addPart (table, partToadd);

-------------------------------------------------- -
-------------------------------------------------- -
-------------------------------------------------- -

www.vipergts96.com/fsim/